<!DOCTYPE html>
<html>
<head>
<title>SSC MARKLIST FORM</title>

<link rel="shortcut icon" type="image/png" href="ms.png"></link>

<!--<script src="myvalidate.js"></script> !-->



<!--JQUERY!-->
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>

<!--
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/script.js"></script> !-->

<script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.8/jquery.validate.min.js"></script> 

<script type="text/javascript">

(function($,W,D)
{
  var JQUERYTULS={};
  JQUERYTULS.UTIL=
  {
  	setupFormValidation:function()
  	{
  		//form validation rules
  		$("#ssc_form").validate({

  			rules:{
  				fn:"required",
  				ln:"required"
  				/*email:{
  					required:true,
  					email:true
  				}*/
  			},
  			messages:{
  				fn:"Please enter your first name",
  				ln:"Please enter your last name"
  				//email:"Please enter a valid email address"
  			}, 
  			submitHandler:function(form){
  				form.submit();
  			}
  		}
  			);
  	}
  }

$(D).ready(function($)
{
	JQUERYTULS.UTIL.setupFormValidation();
});

})(jQuery,window,document);
</script>






</head>
<body>

<style>
div{
margin-left:30%;
margin-right:30%;
}

body{
border:1px solid black;
}

h1{
font-family: Old English Text MT;
}

th{
text-align:left;
}

button{
	background-color: green;
	width: 25%;
}

</style>

<table width=100%>
<tr>
<td><img src="ms.png"></img></td>
<div><td><h1><center>Maharashtra State Board Of Secondary And</center><br>
<center>Higher Secondary Education,Pune<center></h1></td></div>
</tr>
</table>

<hr>

<div>
<form name="ssc_form" method="post" id="ssc_form" novalidate="novalidate">
<fieldset>
<legend>Personal Information</legend>
<table bgcolor="white">

<tr>
<th>First name</th>
<td>:</td>
<td><input type="text" name="fn" /></td>
</tr>

<tr>
<th>Middle name</th>
<td>:</td>
<td><input type="text" name="mn"  /></td>
</tr>

<tr>
<th>Last name</th>
<td>:</td>
<td><input type="text" name="ln"/></td>
</tr>

<tr>
<th>Mother's name</th>
<td>:</td>
<td><input type="text" name="msn"/></td>
</tr>

<tr>
<th>Birthdate</th>
<td>:</td>
<td><input type="date" name="bday"></td>
</tr>


<!--
<tr>
<th>Phone Number</th>
<td>:</td>
<td><input name="pn" maxlength="10" /></td>
</tr>

<tr>
<th>Email Address</th>
<td>:</td>
<td><input name="em" /></td>
</tr>

<tr>
<th>Gender</th>
<td>:</td>
<td><input type="radio" name="gen1" value="f">Female
    <input type="radio" name="gen1" value="m">Male
</td>
</tr>




<tr>
<th>Aadhar(UID) Number</th>
<td>:</td>
<td><input type="number" name="aadhar" /></td>
</tr>


</table>

<fieldset>
<legend>Address Details</legend>
<table bgcolor="white">
<tr>
<th>Address</th>
<td>:</td>
<td><textarea rows="5" cols="50" name="add" /></textarea></td>
</tr>

<tr>
<th>Pincode</th>
<td>:</td>
<td><input style="width:98%" type="number" name="pin" pattern="" /></td>
</tr>



<tr>
<th>Division</th>
<td>:</td>
<td>
<select style="width:100%">

<option value="AM">Amravati</option>
<option value="AU">Aurangabad</option>
<option value="MU">Mumbai(Konkan Region)</option>
<option value="NG">Nagpur</option>
<option value="NS">Nashik</option>
<option value="PU">Pune</option>


</select></td>
</tr>

<tr>
<th>District</th>
<td>:</td>
<td><select style="width:100%">

<option value="ah">ahmednagar</option>
<option value="ak">akola</option>
<option value="am">amravati</option>
<option value="au">aurangabad</option>
<option value="bi">beed</option>
<option value="bh">bhandara</option>
<option value="bu">buldhana</option>
<option value="ch">chandrapur</option>
<option value="dh">dhule</option>
<option value="ga">gadchiroli</option>
<option value="go">gondia</option>
<option value="hi">hingoli</option>
<option value="jg">jalgaon</option>
<option value="jn">jalna</option>
<option value="ko">kolhapur</option>
<option value="la">latur</option>
<option value="mc">mumbai city</option>
<option value="mu">mumbai suburban</option>
<option value="ng">nagpur</option>
<option value="nd">nanded</option>
<option value="nb">nandurbar</option>
<option value="ns">nashik</option>
<option value="os">osmanabad</option>
<option value="pa">parbhani</option>
<option value="pu">pune</option>
<option value="rg">raigad</option>
<option value="rt">ratnagiri</option>
<option value="sn">sangli</option>
<option value="st">satara</option>
<option value="si">sindhudurg</option>
<option value="so">solapur</option>
<option value="th">thane</option>
<option value="wr">wardha</option>
<option value="as">washim</option>
<option value="ytl">yavatmal</option>
<option value="pl">palghar</option>

</select></td>
</tr>

<tr>
<th>Nationality</th>
<td>:</td>
<td><input type="radio" name="n1" value="ind">Indian
    <input type="radio" name="n1" value="other">Other
</td>
</tr>
!-->
</table>
</fieldset>



<fieldset>
<legend>School Details</legend>
<table bgcolor="white">

<!--
<tr>
<th>Name of school</th>
<td>:</td>
<td><textarea rows="5" cols="50" name="add"/>Enter name of school here...</textarea></td>
</tr>

<tr>
<th>Address of school</th>
<td>:</td>
<td><textarea rows="5" cols="50" name="add"/>Enter address here...</textarea></td>
</tr>

<tr>
<th>Pincode</th>
<td>:</td>
<td><input style="width:98%" type="number" name="pin" /></td>
</tr>
!-->
<tr>
<th>Division</th>
<td>:</td>
<td>
<select style="width:100%" name="div">

<option value="AM">Amravati</option>
<option value="AU">Aurangabad</option>
<option value="MU">Mumbai(Konkan Region)</option>
<option value="NG">Nagpur</option>
<option value="NS">Nashik</option>
<option value="PU">Pune</option>

</select></td>
</tr>

<!--
<tr>
<th>District</th>
<td>:</td>
<td><select style="width:100%">

<option value="ah">ahmednagar</option>
<option value="ak">akola</option>
<option value="am">amravati</option>
<option value="au">aurangabad</option>
<option value="bi">beed</option>
<option value="bh">bhandara</option>
<option value="bu">buldhana</option>
<option value="ch">chandrapur</option>
<option value="dh">dhule</option>
<option value="ga">gadchiroli</option>
<option value="go">gondia</option>
<option value="hi">hingoli</option>
<option value="jg">jalgaon</option>
<option value="jn">jalna</option>
<option value="ko">kolhapur</option>
<option value="la">latur</option>
<option value="mc">mumbai city</option>
<option value="mu">mumbai suburban</option>
<option value="ng">nagpur</option>
<option value="nd">nanded</option>
<option value="nb">nandurbar</option>
<option value="ns">nashik</option>
<option value="os">osmanabad</option>
<option value="pa">parbhani</option>
<option value="pu">pune</option>
<option value="rg">raigad</option>
<option value="rt">ratnagiri</option>
<option value="sn">sangli</option>
<option value="st">satara</option>
<option value="si">sindhudurg</option>
<option value="so">solapur</option>
<option value="th">thane</option>
<option value="wr">wardha</option>
<option value="as">washim</option>
<option value="ytl">yavatmal</option>
<option value="pl">palghar</option>

</select></td>
</tr>
!-->
</table>
</fieldset>








</fieldset>
<br>
<fieldset>
<legend>Marks</legend>
ENTER YOUR SSC MARKS:-
<table bgcolor="white">

<tr>
<th>English</th>
<td>:</td>
<td><input type="number" name="e"/></td>
</tr>

<tr>
<th>Hindi-Sanskrit</th>
<td>:</td>
<td><input type="number" name="h"/></td>
</tr>

<tr>
<th>Marathi</th>
<td>:</td>
<td><input type="number" name="m"/></td>
</tr>

<tr>
<th>Mathematics</th>
<td>:</td>
<td><input type="number" name="mt"/></td>
</tr>

<tr>
<th>Science &Technology</th>
<td>:</td>
<td><input type="number" name="s"/></td>
</tr>

<tr>
<th>Social Sciences</th>
<td>:</td>
<td><input type="number" name="ss"/></td>
</tr>

<tr>
<th>Drawing &Painting(GR)</th>
<td>:</td>
<td><input type="text"  pattern="[A,B,C,D]" name="d"/></td>
</tr>

<tr>
<th>Health and Physical Education(GR)</th>
<td>:</td>
<td><input type="text"  pattern="[A,B,C,D]" name="h" /></td>
</tr>

<tr>
<th>Social Service(GR)</th>
<td>:</td>
<td><input type="text"  pattern="[A,B,C,D]" name="sv"/></td>
</tr>

<tr>
<th>Personality Development(GR)</th>
<td>:</td>
<td><input type="text"  pattern="[A,B,C,D]" name="pd"/></td>
</tr>

<tr>
<th>Environment Education(GR)</th>
<td>:</td>
<td><input type="text"  pattern="[A,B,C,D]" name="ee"/></td>
</tr>


</table>
</fieldset>






<br>

<fieldset>
<legend>REQUIRED</legend>
<table>
<tr>
<th>Seat No.</th>
<td>:</td>
<td><input type="text" name="sn"></th>
</tr>
<tr>
<th>Centre No.</th>
<td>:</td>
<td><input type="number" name="cn"></th>
</tr>
<tr>
<th>School No.</th>
<td>:</td>
<td><input type="text" name="scn"></th>
</tr>
</table>
</fieldset>
<br>

<!--
<fieldset>
<legend>File uploads</legend>
<table bgcolor="white">
<tr>
<th>Upload your photo</th>
<td>:</td>
<td><input type="file" name="fileupload1" accept="image"></td>
</tr>

<tr>
<th>Upload your signature</th>
<td>:</td>
<td><input type="file" name="fileupload2" accept="image"></td>
</tr>
</table>

</fieldset>

!-->
<br>


<center><button type="submit" name="submit" value="submit"/>Submit
<button type="reset" name="reset" value="reset"/>Reset</center>
</form>
</div>
</body>
</html>

<?php
if(isset($_POST['submit']))
{
$fn=$_POST["fn"];
$mn=$_POST["mn"];
$ln=$_POST["ln"];
$msn=$_POST["msn"];

$bday=$_POST["bday"];

$div=$_POST["div"];
$seat=$_POST["sn"];
$cent=$_POST["cn"];
$scn=$_POST["scn"];

$m1=$_POST["e"];
$m2=$_POST["h"];
$m3=$_POST["m"];
$m4=$_POST["mt"];
$m5=$_POST["s"];
$m6=$_POST["ss"];
$m7=$_POST["d"];
$m8=$_POST["h"];
$m9=$_POST["sv"];
$m10=$_POST["pd"];
$m11=$_POST["ee"];

include "connect.php";

$sql = "INSERT INTO details VALUES('$fn','$mn','$ln','$msn', '$bday', '$div' ,'$seat', '$cent', '$scn' ,'$m1', '$m2', '$m3', '$m4' ,'$m5' ,'$m6' ,'$m7' ,'$m8' ,'$m9', '$m10', '$m11')";
      
		$result = mysqli_query($con,$sql);


		echo "<h2><font color=green>Member successfully added</font></h2>";
}
?>	