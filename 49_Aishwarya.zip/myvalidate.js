
 function myFunction() {

 

 var x = document.forms["ssc_form"]["fn"];

if (x.value == "") {
        alert("FName should not be blank !!");
        return false;
}


if (! allLetter(x)) {
	alert("FName should be all characters!!");
	return false;
}


var m = document.forms["ssc_form"]["ln"];

if (m.value == "") {
	alert("lName should not be blank !!");
        return false;
}


if (! allLetter(m)) {
	alert("lName should be all characters!!");
	return false;
}
	



var y = document.forms["ssc_form"]["pn"];

  if (y.value == "") {
                alert("Contact No. should not be blank !!");
		            
		return false;
            }

	if (! allnumeric(y)) {
		 alert('Please input numeric characters only');
      return false;}
      if(y<10&&y>10)
      {
		 alert('Please enter valid no');
      return false;
      
	}

var z = document.forms["ssc_form"]["em"];

  if (z.value == "") {
                alert("Email should not be blank !!");
		            
		return false;
            }

	if (! ValidateEmail(z)) {
		 alert('Please input valid Email ID!!!');
      return false;
	}

}
 function allLetter(inputtxt)
                {
                 var letters = /^[A-Za-z]+$/;
                 if(inputtxt.value.match(letters))
                   {
              	     return true;
                   }
                 else
                   {
              	     return false;
                   }
                }


            function allnumeric(inputtxt)
               {
                  var numbers = /^[0-9]+$/;
                  if(inputtxt.value.match(numbers))
                  {
                    return true;
                  }
                  else
                  {
                    return false;
                  }
               }

  

            function limit(element,limit)
              {
                var max_chars = limit;

                  if(element.value.length > max_chars) {
                    element.value = element.value.substr(0, max_chars);
                  }
              }

			
			 
			function ValidateEmail(inputText)
			 {
				var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
				if(inputText.value.match(mailformat))
					{
					
					return true;
					}
				else
					{
					return false;
					}
			}


