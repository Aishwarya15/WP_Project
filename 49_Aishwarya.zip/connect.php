<?php

	$servername = "localhost" ;
	$username   = "root" ;
	$password   = "" ;
	$db ="sscform";
/*
@mysqli_connect("$servername","$username","$password") or die("Could not connect to mysql");
@mysqli_select_db("$db") or die("No database");


echo "succesful";

*/

	// Create connection
	$con = new mysqli($servername, $username, $password,$db);
	
	//Check connection
	if ($con -> connect_error)
	{
		die ("Connection failed : ". $con -> connect_error);
	}
	else
	
	echo "Connected sucessfully <br>";




//	$db = new mysqli('$servername','$username' ,'$password','$db') or die("Could not connect!");

	
?>